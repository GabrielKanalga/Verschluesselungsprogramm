﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Encript
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public int key = 0;
        public string alphabet = "abcdefghijklmnopqrstuvwxjz";
        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)

        {
            if(key == 0)
            {
                MessageBox.Show("Bitte wählen Sie einen Schlüssel aus");
            }
            else if(versch_txt.Text.Length == 0)
            {
                MessageBox.Show("Bitte eingabe tätigen");
            }
            else if(key == 1)
            {
               MessageBox.Show(verschluesselnAGA(versch_txt.Text));
            }else if(key == 2)
            {
                MessageBox.Show(VerschlüsselungJer(versch_txt.Text));
            }else if(key == 3)
            {
                MessageBox.Show(verschlüsselunghektor(versch_txt.Text));
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Key_auswahl.Text.Equals("Agamenon"))
            {
                MessageBox.Show("Agamenon wurde ausgewählt");
                key = 1;
            }else if (Key_auswahl.Text.Equals("Jeronimo"))
            {
                MessageBox.Show("Jeronimo wurde ausgewählt");
                key = 2;
            }else if (Key_auswahl.Text.Equals("Hektor"))
            {
                MessageBox.Show("Hektor wurde ausgewählt");
                key = 3;
            }
            else
            {
                MessageBox.Show("Bitte wählen Sie einen Schlüssel aus");
               
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (key == 0 && entsch_txt.Text.Length > 1)
            {
                MessageBox.Show("Bitte wählen Sie einen Schlüssel aus");
            }
            else if (entsch_txt.Text.Length == 0)
            {
                MessageBox.Show("Bitte eingabe tätigen");
            }else if(key == 1)
            {
                MessageBox.Show(entschluesselnAGA(entsch_txt.Text));
            }
            else if (key == 2)
            {
                MessageBox.Show(entschlüsselungJer(entsch_txt.Text));
            }else if (key == 3)
            {
                MessageBox.Show(entschlüsselunghektor(entsch_txt.Text));
            }



        }
        public string verschluesselnAGA(string text)
        {
          
            string verschlüsselteswort = "Ihr Code wurde mit dem Agamenon Key Verschlüsselt: ";
            int posi = 0;

            for (int i = 0; i < text.Length; i++)
            {
                char buchstabe = text[i];

                posi = buchstabe - 'a' + 1 ;

                verschlüsselteswort = verschlüsselteswort+"," + posi;
            }



            return verschlüsselteswort;
        }
        public string entschluesselnAGA(string codestring)
        {
            
           
            string entschlüsselteswort = "Ihr Wort wurde mit dem Agamenon Key Entschlüsselt: ";
            string schlüsselwort = " ";
            int norepeat = 0;


            for (int i = 0; i < codestring.Length; i++)
            {
                char buchsta = codestring[i];
                char sec ='.';
                int secbuch = 0;


                if (i < codestring.Length-1 ) {
                    if (codestring[i + 1] !=',')
                    {
                        secbuch = codestring[i + 1] -48 ;
                    }
                    else
                    {
                        sec = ',';

                    }

                }
                else if(i+1==codestring.Length)
                {
                    sec = ',';
                }

                



                if (buchsta.Equals(',')|| norepeat ==1)
                {
                    norepeat = 0;

                }else if (sec == ',')
                {
                   int noidea = buchsta - 49;
                    char alph = alphabet[noidea];
                    schlüsselwort = schlüsselwort + alph;
                }
                else
                {
                    int noidea = buchsta - 49;
                    int zweistell = 0;
                    if(noidea == 0)
                    {
                        noidea = 9;
                         zweistell = noidea  + secbuch;
                    }
                    else
                    {
                         zweistell = noidea * 10 + secbuch;
                    }
                    

                    char alph = alphabet[zweistell];
                    schlüsselwort = schlüsselwort + alph;
                    norepeat++;
                }
                
            }




            entschlüsselteswort = entschlüsselteswort + schlüsselwort;


                return entschlüsselteswort;
        }
        
        public string VerschlüsselungJer(string text)
        {
            string verschlüsseltertext = "Ihr Code wurde mit dem Jeronimo Key Verschlüsselt: ";
            string schlüsselwort = "";

            for(int i = 0; i < text.Length; i++)
            {
                int posi;
                if (text[i] == 'z')
                {
                    posi = -1;
                }
                else
                {
                    posi = alphabet.IndexOf(text[i]);

                }
                schlüsselwort = schlüsselwort + alphabet[posi + 1];

               
                
            }


            verschlüsseltertext = verschlüsseltertext + schlüsselwort;
            return verschlüsseltertext;
        }
        public string entschlüsselungJer(string text)
        {
            string verschlüsseltertext = "Ihr Wort wurde mit dem Jeronimo Key Entschlüsselt:  ";
            string schlüsselwort = "";


            for(int i = 0; i < text.Length; i++)
            {
                int posi;
                if(text[i] == 'a')
                {
                    posi = 26;
                }
                else
                {
                    posi = alphabet.IndexOf(text[i]);
                }
                schlüsselwort = schlüsselwort + alphabet[posi -1];
            }



            verschlüsseltertext = verschlüsseltertext + schlüsselwort;
            return verschlüsseltertext;

        }

        public string verschlüsselunghektor(string text)
        {

            string verschlüsseltertext = "Ihr Code wurde mit dem Hektor Key Verschlüsselt: ";
            string schlüsselwort = "";


            for (int i = 0; i < text.Length; i++)
            {
                double posi;
                
                    posi = alphabet.IndexOf(text[i]);

                double vercode = Math.Pow(posi,5);
                if (vercode == 0)
                {
                    schlüsselwort = schlüsselwort + 26 + ",";
                }else if(vercode == 1)
                {
                    schlüsselwort = schlüsselwort + 111 + ",";
                }
                else
                {
                    schlüsselwort = schlüsselwort + vercode + ",";
                }


            }

            verschlüsseltertext = verschlüsseltertext + schlüsselwort;




            return verschlüsseltertext;


        }
        public string entschlüsselunghektor(string codestring)
        {
            string entschlüsselteswort = "Ihr Wort wurde mit dem Hektor Key Entschlüsselt: ";
            string schlüsselwort = " ";
            int repet = 0;
            double zahl = 0;

            for (int i =0; i < codestring.Length; i++)
            {
                if (codestring[i].Equals(','))
                {
                    double mehrstellzahl = 0;
                    int count = 0;
                    
                    for (int j = 0; j < i-repet; j++)
                    {
                        
                         zahl = (double)codestring[j+repet] -48;

                        

                        mehrstellzahl = mehrstellzahl* 10 + zahl;
                       

                        if(j == i-repet - 1)
                        {
                            if (mehrstellzahl == 26)
                            {
                                schlüsselwort = schlüsselwort + "a";

                            }
                            else if (mehrstellzahl == 111)
                            {
                                schlüsselwort = schlüsselwort + "b";
                            }
                            else
                            {
                                double posi = Math.Pow(mehrstellzahl, 0.2);
                                char buchstabe = alphabet[(int)posi];
                                schlüsselwort = schlüsselwort + buchstabe;
                            }
                            count++;
                            if(count == 0)
                            {
                                repet = repet + i;
                            }
                            else
                            {
                                repet = repet + j+2;
                            }
                        }
                    }

                }


            }


            entschlüsselteswort = entschlüsselteswort + schlüsselwort;

            return entschlüsselteswort;

            }




            

        }
       
    }
    

